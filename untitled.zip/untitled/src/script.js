const display = document.getElementById('display');

// Adds the number/symbol to the screen
function appendToDisplay(input) {
    display.value += input;
}

// Clears everything (The 'C' button)
function clearDisplay() {
    display.value = "";
}

// Deletes just the last character
function deleteLast() {
    display.value = display.value.slice(0, -1);
}

// The math engine
function calculate() {
    try {
        // eval() turns the string text into a math answer
        display.value = eval(display.value);
    } catch (error) {
        display.value = "Error";
    }
}